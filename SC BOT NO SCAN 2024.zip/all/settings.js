const fs = require('fs')
const chalk = require('chalk')

global.owner = "6283839990008"
global.namabot = "BOTT PEDAI"
global.botname = "BOTT PEDIA"
global.autoJoin = false
global.keyopenai = `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`
global.codeInvite = "FwtMxovJqW3Jj55x524hjT"
global.thumb = fs.readFileSync("./thumb.png")
global.bugthomz = fs.readFileSync("./bugthomz.png")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "Sticker By ADITYA STOR JB"

global.namastore = "ADITYA STOR JB"
global.nodana = "085752284357"
global.nogopay = "085752284357"
global.noovo = "083839990008"

global.domain = 'https://serverpanel.pannelpriv.my.id' // Isi Domain Lu
global.apikey = 'ptla_Xc06iFu1FgA5WkKoWPTaEs9C8HWWjADyZ3PaQgLLdfo' // Isi Apikey Plta Lu
global.capikey = 'ptlc_zxpF3b6Jpvy8vIKKRfqnYMCUg6q2rYR6LynwQGCd24q' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

global.wlcm = []
global.wlcmm = []

//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})